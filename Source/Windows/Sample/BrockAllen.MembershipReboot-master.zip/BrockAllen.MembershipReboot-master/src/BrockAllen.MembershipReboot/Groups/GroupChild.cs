﻿/*
 * Copyright (c) Brock Allen.  All rights reserved.
 * see license.txt
 */

using System;

namespace BrockAllen.MembershipReboot
{
    public class GroupChild
    {
        public virtual Guid ChildGroupID { get; protected internal set; }
    }
}
